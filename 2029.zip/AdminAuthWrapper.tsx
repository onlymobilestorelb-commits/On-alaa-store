/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Shield } from 'lucide-react';
import { Language, translations } from '../translations';

/**
 * AdminAuthWrapper
 * ------------------
 * Gatekeeper for the Admin Dashboard view.
 * - Shows a branded "ON ALAA STORE" login screen until the correct
 *   password is entered.
 * - Persists the session in sessionStorage (onalaa_admin_session), so
 *   the admin stays logged in while navigating the dashboard, but is
 *   forced to re-authenticate whenever the browser/tab is closed
 *   (sessionStorage is cleared automatically by the browser).
 * - Renders nothing from the dashboard (children) until authenticated.
 *
 * SECURITY NOTE: The password is hardcoded in the client bundle, so
 * it's technically visible to anyone who inspects the JS. This matches
 * the requested spec, but it's a deterrent, not real access control.
 * True protection (hiding orders/product data from anyone but you)
 * requires a server-side check, e.g. a Vercel serverless function +
 * signed httpOnly cookie. Ask if you'd like that version built too.
 */

const ADMIN_PASSWORD = 'A123321A';
const SESSION_KEY = 'onalaa_admin_session';

interface AdminAuthWrapperProps {
  children: React.ReactNode;
  language: Language;
}

export default function AdminAuthWrapper({ children, language }: AdminAuthWrapperProps) {
  const t = translations[language];
  const [authenticated, setAuthenticated] = React.useState(false);
  const [checked, setChecked] = React.useState(false);
  const [password, setPassword] = React.useState('');
  const [error, setError] = React.useState(false);

  React.useEffect(() => {
    const session = sessionStorage.getItem(SESSION_KEY);
    setAuthenticated(session === 'true');
    setChecked(true);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === ADMIN_PASSWORD) {
      sessionStorage.setItem(SESSION_KEY, 'true');
      setError(false);
      setAuthenticated(true);
    } else {
      setError(true);
      setPassword('');
    }
  };

  // Avoid flashing the dashboard before we've checked sessionStorage
  if (!checked) return null;

  if (authenticated) return <>{children}</>;

  return (
    <div
      dir={language === 'ar' ? 'rtl' : 'ltr'}
      className="min-h-[70vh] w-full flex items-center justify-center px-4 py-16"
    >
      <div className="w-full max-w-sm">
        <div className="text-center mb-8">
          <div className="w-14 h-14 mx-auto mb-4 bg-[#FCD34D] rounded-2xl flex items-center justify-center shadow-md">
            <Shield className="w-7 h-7 text-[#0F172A]" />
          </div>
          <h1 className="text-2xl font-black tracking-tight text-[#0F172A] font-display">
            {t.adminLoginTitle}
          </h1>
          <p className="mt-1 text-sm text-slate-500 font-medium">{t.adminLoginSubtitle}</p>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xl"
        >
          <label
            htmlFor="admin-password"
            className="block text-sm font-semibold text-slate-700 mb-2"
          >
            {t.adminLoginLabel}
          </label>
          <input
            id="admin-password"
            type="password"
            autoFocus
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              if (error) setError(false);
            }}
            placeholder={t.adminLoginPlaceholder}
            className={`w-full rounded-xl px-4 py-3 bg-[#F3F4F6] text-[#0F172A] border-2 outline-none transition-colors font-medium
              ${error ? 'border-red-500 focus:border-red-500' : 'border-transparent focus:border-[#FCD34D]'}`}
          />

          {error && (
            <p className="mt-2 text-sm text-red-500 font-bold">{t.adminLoginDenied}</p>
          )}

          <button
            type="submit"
            className="mt-4 w-full rounded-xl bg-[#0F172A] text-white font-black uppercase tracking-wide text-sm py-3 active:scale-[0.98] transition-transform hover:bg-[#1E293B]"
          >
            {t.adminLoginButton}
          </button>
        </form>

        <p className="mt-6 text-center text-xs text-slate-400 font-medium">
          {t.adminLoginFooter}
        </p>
      </div>
    </div>
  );
}
